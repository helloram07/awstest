#!/bin/bash

# Start web server
service httpd start
